import React from 'react';

function Home(props) {
    return (
        <h1>Logo</h1>
    );
}

export default Home;