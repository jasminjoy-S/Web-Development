import React from 'react';
import logo from './logo.svg';
import './App.css';
import Menu from './menu/Menu';

function App() {
  return (
      <Menu />
  );
}

export default App;
