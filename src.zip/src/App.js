import React from 'react';
import Menu from './menu/Menu';

function App() {
  return (
      <Menu />
  );
}

export default App;
