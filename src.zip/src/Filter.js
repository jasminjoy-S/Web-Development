import React from 'react';

function Filter(props) {
    return (
        <h2>Water Filter</h2>
    );
}

export default Filter;