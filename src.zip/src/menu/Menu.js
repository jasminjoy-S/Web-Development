import React from 'react';
import { BrowserRouter, Switch, Link, Route } from 'react-router-dom';
import Home from '../Home';
import Filter from '../Filter';
import './Menu.css';

function Menu(props) {
    return (
        <BrowserRouter>
            <nav>
                <ul>
                    <li>Home</li>
                    <li>Technology <span class="down-arrow"></span>
                        <div>
                            <ul>
                                <li><Link to={'/water-filter-uae.html'}>Water Filters</Link></li>
                                <li>Water Purification</li>
                                <li>Water Softener</li>
                                <li>Desalination</li>
                                <li>Reverse Osmosis</li>
                            </ul>
                        </div>
                    </li>
                    <li>Parts</li>
                    <li>Industries <span class="down-arrow"></span>
                        <div>
                            <ul>
                                <li>Water Filters</li>
                                <li>Water Purifier</li>
                                <li>Reverse Osmosis</li>
                            </ul>
                        </div>
                    </li>
                    <li>Contact</li>
                </ul>
                <Switch>
                    <Route path='/water-filter-uae.html' component={Filter} />
                </Switch>
            </nav>
        </BrowserRouter>
    );
}

export default Menu;