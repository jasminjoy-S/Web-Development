import React from 'react';
import './Menu.css';

function Menu(props) {
    return (
        <nav>
            <ul>
                <li>Home</li>
                <li>Technology <span class="down-arrow"></span>
                    <div>
                        <ul>
                            <li>Water Filters</li>
                            <li>Water Purifier</li>
                            <li>Reverse Osmosis</li>
                        </ul>
                    </div>
                </li>
                <li>Parts</li>
                <li>Industries <span class="down-arrow"></span>
                    <div>
                        <ul>
                            <li>Water Filters</li>
                            <li>Water Purifier</li>
                            <li>Reverse Osmosis</li>
                        </ul>
                    </div>
                </li>
                <li>Contact</li>
            </ul>
        </nav>
    );
}

export default Menu;