import React from 'react';
import './ButtonMenu.css';

function ButtonMenu(props) {
    return (
        <nav>
            <div class="navbar">
                <button>Home</button>
                <button>Technologies <span class="down-arrow"></span>
                    <ul>
                        <li>Water Filtration</li>
                        <li>Water Purification</li>
                        <li>Reverse Osmosis</li>
                    </ul>
                </button>
                <button>Industries</button>
                <button>Parts</button>
                <button>Contact</button>
            </div>
        </nav>

    );
}

export default ButtonMenu;